import joi from "joi";

export const signUpValidator = joi.object({
  email: joi.string().email().required().messages({
    "any.required": "Please Enter Your Eail",
    "string.empty": "Please Enter Your Email",
  }),
  password: joi.string().required().messages({
    "any.required": "Please Enter Your Password",
    "string.empty": "Please Enter Your Password",
  }),
});

export const resendOTPValidator = joi.object({});

export const verifySignUpValidator = joi.object({
  otp: joi.string().required().messages({
    "any.required": "Please Enter Your OTP",
    "string.empty": "Please Enter Your OTP",
  }),
});

export const createProfileValidator = joi.object({
  fullName: joi.string().required().messages({
    "any.required": "Please Enter Your Full Name",
    "string.empty": "Please Enter Your Full Name",
  }),
  contactNumber: joi.string().required().messages({
    "any.required": "Please Enter Your Contact Number",
    "string.empty": "Please Enter Your Contact Number",
  }),
  address: joi.string().required().messages({
    "any.required": "Please Enter Your Address",
    "string.empty": "Please Enter Your Address",
  }),
  preferences: joi.string().required().messages({
    "any.required": "Please Enter Your Preferences",
    "string.empty": "Please Enter Your Preferences",
  }),
});

export const registerCarValidator = joi.object({
  carName: joi.string().required().messages({
    "any.required": "Please Enter Your Car Name",
    "string.empty": "Please Enter Your Car Name",
  }),
  carModel: joi.string().required().messages({
    "any.required": "Please Enter Your Car Model",
    "string.empty": "Please Enter Your Car Model",
  }),
  carPlateNumber: joi.string().required().messages({
    "any.required": "Please Enter Your Car Plate Number",
    "string.empty": "Please Enter Your Car Plate Number",
  }),
  licenseNumber: joi.string().required().messages({
    "any.required": "Please Enter Your License Number",
    "string.empty": "Please Enter Your License Number",
  }),
});

export const forgotPasswordValidator = joi.object({
  email: joi.string().email().required().messages({
    "any.required": "Please Enter Your Eail",
    "string.empty": "Please Enter Your Email",
  }),
});

export const verifyForgotPasswordValidator = joi.object({
  otp: joi.string().required().messages({
    "any.required": "Please Enter Your OTP",
    "string.empty": "Please Enter Your OTP",
  }),
});

export const resetPasswordValidator = joi.object({
  newPassword: joi.string().required().messages({
    "any.required": "Please Enter Your New Password",
    "string.empty": "Please Enter Your New Password",
  }),
});

export const logInValidator = joi.object({
  deviceType: joi.string().required().messages({
    "any.required": "Please Enter Device Type",
    "string.empty": "Please Enter Device Type",
  }),
  deviceToken: joi.string().email().required().messages({
    "any.required": "Please Enter Device Token",
    "string.empty": "Please Enter Device Token",
  }),
  email: joi.string().email().required().messages({
    "any.required": "Please Enter Your Eail",
    "string.empty": "Please Enter Your Email",
  }),
  password: joi.string().required().messages({
    "any.required": "Please Enter Your Password",
    "string.empty": "Please Enter Your Password",
  }),
});
