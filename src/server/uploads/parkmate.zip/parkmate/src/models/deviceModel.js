import mongoose from "mongoose";

const DeviceSchema = new mongoose.Schema(
  {
    authId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "auth",
    },

    deviceType: {
      type: String,
      required: true,
      enum: ["web", "android", "ios", "windows", "osx", "linux", "postman"],
    },

    deviceToken: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const deviceModel = mongoose.model("device", DeviceSchema);

export default deviceModel;
