import mongoose from "mongoose";

const ProfileSchema = mongoose.Schema(
  {
    authId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "auth",
    },

    profileImageId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "file",
    },

    fullName: {
      type: String,
      required: true,
      trim: true,
    },

    contactNumber: {
      type: String,
      required: true,
      trim: true,
    },

    address: {
      type: String,
      required: true,
      trim: true,
    },

    preferences: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

const profileModel = mongoose.model("profile", ProfileSchema);

export default profileModel;
