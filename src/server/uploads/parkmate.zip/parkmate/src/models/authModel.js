import mongoose from "mongoose";

const AuthSchema = mongoose.Schema(
  {
    deviceId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
      ref: "device",
    },

    email: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },

    password: {
      type: String,
      required: true,
      trim: true,
    },

    isVerified: {
      type: Boolean,
      required: true,
      default: false,
    },

    isProfileCreated: {
      type: Boolean,
      required: true,
      default: false,
    },

    isCarRegistered: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

const authModel = mongoose.model("auth", AuthSchema);

export default authModel;
