import mongoose from "mongoose";

const CarSchema = mongoose.Schema(
  {
    authId: {
      type: mongoose.Schema.Types.ObjectId,
      required: false,
      ref: "auth",
    },

    carImageId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "file",
    },

    carName: {
      type: String,
      required: true,
      trim: true,
    },

    carModel: {
      type: String,
      required: true,
      trim: true,
    },

    carPlateNumber: {
      type: String,
      required: true,
      trim: true,
    },

    licenseNumber: {
      type: String,
      required: true,
      trim: true,
    },
  },
  {
    timestamps: true,
  }
);

const carModel = mongoose.model("car", CarSchema);

export default carModel;
