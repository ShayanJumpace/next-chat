import mongoose from "mongoose";

const OTPScheme = mongoose.Schema(
  {
    authId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "auth",
    },

    otpKey: {
      type: String,
      required: true,
      trim: true,
    },

    isUsed: {
      type: Boolean,
      required: true,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

const otpModel = mongoose.model("otp", OTPScheme);

export default otpModel;
