import mongoose from "mongoose";

const FileScheme = mongoose.Schema(
  {
    authId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      ref: "auth",
    },

    fileName: {
      type: String,
      required: true,
    },

    fileType: {
      type: String,
      required: true,
    },
  },
  {
    timestamps: true,
  }
);

const fileModel = mongoose.model("file", FileScheme);

export default fileModel;
