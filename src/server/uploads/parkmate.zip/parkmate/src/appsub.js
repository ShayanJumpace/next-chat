import path from "path";
import { fileURLToPath } from "url";
import express from "express";
import morgan from "morgan";
import morganBody from "morgan-body";
import cors from "cors";
import bodyParser from "body-parser";
import { connectDB } from "./db/index.js";
import { AuthRouters } from "./routers/authRouter.js";
import { ProfileRouter } from "./routers/profileRouter.js";
import { CarRouter } from "./routers/carRouter.js";
import { ResHandler } from "./Utils/ResponseHandler/ResHandler.js";

export const filename = fileURLToPath(import.meta.url);
export const dirname = path.dirname(filename);

export const app = express();

const API_PreFix = "/api/v1";

const corsOptions = {
  origin: "*",
};

app.use("/", express.static("uploads"));

app.use(morgan("dev"));
morganBody(app, {
  prettify: true,
  logReqUserAgent: true,
  logReqDateTime: true,
});

app.use(cors(corsOptions));

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

connectDB();

app.use(API_PreFix, AuthRouters);
app.use(API_PreFix, ProfileRouter);
app.use(API_PreFix, CarRouter);

app.use(ResHandler);
