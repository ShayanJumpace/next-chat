import { Router, application } from "express";
import {
  signUp,
  verifySignUp,
  resendOTP,
  forgotPassword,
  verifyForgotPassword,
  resetPassword,
} from "../controllers/authController.js";

import ephemeralAccessMiddleware from "../middlewares/ephemeralAccessMiddleware.js";

export let AuthRouters = Router();

application.prefix = Router.prefix = function (path, middleware, configure) {
  configure(AuthRouters);
  this.use(path, middleware, AuthRouters);
  return AuthRouters;
};

AuthRouters.route("/signup").post(signUp);
AuthRouters.route("/forgotpassword").post(forgotPassword);
AuthRouters.prefix("/auth", ephemeralAccessMiddleware, async function () {
  AuthRouters.route("/resendotp").post(resendOTP);
  AuthRouters.route("/verifysignup").post(verifySignUp);
  AuthRouters.route("/verifyforgotpassword").post(verifyForgotPassword);
  AuthRouters.route("/resetpassword").post(resetPassword);
});
