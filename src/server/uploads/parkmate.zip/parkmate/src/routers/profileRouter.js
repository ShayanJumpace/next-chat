import { Router, application } from "express";
import { createProfile } from "../controllers/profileController.js";
import { handleMultipartData } from "../Utils/MultipartData.js";

import ephemeralAccessMiddleware from "../middlewares/ephemeralAccessMiddleware.js";

export let ProfileRouter = Router();

application.prefix = Router.prefix = function (path, middleware, configure) {
  configure(ProfileRouter);
  this.use(path, middleware, ProfileRouter);
  return ProfileRouter;
};

ProfileRouter.prefix("/profile", ephemeralAccessMiddleware, async function () {
  ProfileRouter.route("/createprofile").post(
    handleMultipartData.single("profileImage"),
    createProfile
  );
});
