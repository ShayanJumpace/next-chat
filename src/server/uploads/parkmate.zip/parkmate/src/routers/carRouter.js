import { Router, application } from "express";
import { registerCar } from "../controllers/carController.js"; //
import { handleMultipartData } from "../Utils/MultipartData.js";

import ephemeralAccessMiddleware from "../middlewares/ephemeralAccessMiddleware.js";

export const CarRouter = Router();

application.prefix = Router.prefix = function (path, middleware, configure) {
  configure(CarRouter);
  this.use(path, middleware, CarRouter);
  return CarRouter;
};

CarRouter.prefix("/car", ephemeralAccessMiddleware, async function () {
  CarRouter.route("/registercar").post(
    handleMultipartData.single("carImage"),
    registerCar
  );
});
