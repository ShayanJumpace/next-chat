import { joseJwtDecrypt } from "../Utils/AccessTokenManagement/Tokens.js";
import CustomError from "../Utils/ResponseHandler/CustomError.js";

export default async function ephemeralAccessMiddleware(req, res, next) {
  const AuthHeader =
    req.headers.authorization ||
    req.body.token ||
    req.query.token ||
    req.headers["x-access-token"];

  if (!AuthHeader) {
    return next(CustomError.unauthorized());
  }

  const parts = AuthHeader.split(" ");

  try {
    if (parts.length !== 2) {
      return next(CustomError.unauthorized());
    }

    const [scheme, token] = parts;

    if (!/^Bearer$/i.test(scheme)) {
      return next(CustomError.unauthorized());
    }

    const authToken = await joseJwtDecrypt(token);

    if (!authToken) {
      return next(CustomError.unauthorized());
    }

    req.auth = authToken;

    return next();
  } catch (error) {
    return next(CustomError.unauthorized());
  }
}
