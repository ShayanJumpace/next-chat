import authModel from "../models/authModel.js";
import otpModel from "../models/otpModel.js";
import { hashPassword } from "../Utils/SecuringPassword.js";
import { sendEmails } from "../Utils/SendEmail.js";
import { otpTokenGen } from "../Utils/AccessTokenManagement/Tokens.js";
import CustomError from "../Utils/ResponseHandler/CustomError.js";
import CustomSuccess from "../Utils/ResponseHandler/CustomSuccess.js";
import {
  resetPasswordValidator,
  forgotPasswordValidator,
  resendOTPValidator,
  signUpValidator,
  verifyForgotPasswordValidator,
  verifySignUpValidator,
} from "../validators/authValidators.js";

export async function signUp(req, res, next) {
  try {
    const { error } = signUpValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    const { email, password } = req.body;

    const auth = await authModel.findOne({ email });
    if (auth) {
      return next(CustomError.badRequest("user already exist."));
    }

    const hashedPassword = hashPassword(password);
    const authData = {
      email,
      password: hashedPassword,
    };
    const newAuth = await authModel.create(authData);

    const otp = Math.floor(Math.random() * 90000) + 100000;
    const otpData = {
      authId: newAuth._doc._id,
      otpKey: otp,
    };
    await otpModel.create(otpData);

    const emailData = {
      subject: "Park Mate - Account Verification",
      html: `
            <div
                style = "padding:20px 20px 40px 20px; position: relative; overflow: hidden; width: 100%;"
            >
                <div style="z-index:1; position: relative;">
                <header style="padding-bottom: 20px">
                <div class="logo" style="text-align:center;">
                    <img 
                    style="width: 150px;" 
                    src="cid:logo" alt="logo" />
                </div>
                </header>
                <main 
                style= "padding: 20px; background-color: #f5f5f5; border-radius: 10px; width: 80%; margin: 0 auto; margin-bottom: 20px; font-family: 'Poppins', sans-serif;"
                >
                <h1 
                    style="color: #FD6F3B; font-size: 30px; font-weight: 700;"
                >Welcome To Park Mate</h1>
                <p
                    style="font-size: 24px; text-align: left; font-weight: 500; font-style: italic;"
                >Hi,</p>
                <p 
                    style="font-size: 20px; text-align: left; font-weight: 500;"
                > Please use the following OTP to verify your account.</p>
                <h2
                    style="font-size: 36px; font-weight: 700; padding: 10px; width:100%; text-align:center;color: #FD6F3B; text-align: center; margin-top: 20px; margin-bottom: 20px;"
                >${otp}</h2>
                <p style = "font-size: 16px; font-style:italic; color: #343434">If you did not request this email, kindly ignore this. If this is a frequent occurence <a
                style = "color: #FD6F3B; text-decoration: none; border-bottom: 1px solid #FD6F3B;" href = "#"
                >let us know.</a></p>
                <p style = "font-size: 20px;">Regards,</p>
                <p style = "font-size: 20px;">Dev Team</p>
                </main>
                </div>
            <div>
            `,
      attachments: [
        {
          filename: "logo.jpg",
          path: "./assets/logo.jpg",
          cid: "logo",
          contentDisposition: "inline",
        },
      ],
    };

    sendEmails(email, emailData.subject, emailData.html, emailData.attachments);

    const token = await otpTokenGen({ authData, otp });

    return next(
      CustomSuccess.createSuccess(
        { token, otp },
        "verification otp has been sent",
        200
      )
    );
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}

export async function verifySignUp(req, res, next) {
  try {
    const { error } = verifySignUpValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    const { auth } = req;
    const { otp } = req.body;

    const otpFromToken = auth.payload.data.otp;
    const authData = auth.payload.data.authData;

    if (otpFromToken.toString() !== otp) {
      return next(CustomError.createError("invalid otp", 401));
    }

    const foundAuth = await authModel.findOne({
      email: authData.email,
    });
    if (!foundAuth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    const foundOTP = await otpModel.findOne({
      authId: foundAuth._doc._id,
    });
    if (!foundOTP || foundOTP.otpKey !== otp || foundOTP.isUsed) {
      return next(CustomError.badRequest("otp already expired."));
    }

    await authModel.updateOne({ email: authData.email }, { isVerified: true });
    await otpModel.updateOne({ authId: foundAuth._doc._id }, { isUsed: true });

    const token = await otpTokenGen({ authData });

    return next(
      CustomSuccess.createSuccess(
        { token, authData },
        "user verified succesfully",
        200
      )
    );
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}

export async function resendOTP(req, res, next) {
  try {
    const { error } = resendOTPValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    const { auth } = req;

    const authData = auth.payload.data.authData;

    const foundAuth = await authModel.findOne({
      email: authData.email,
    });
    if (!foundAuth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    const otp = Math.floor(Math.random() * 90000) + 100000;

    await otpModel.updateOne(
      { authId: foundAuth._doc._id },
      { otpKey: otp, isUsed: false }
    );

    const emailData = {
      subject: "Park Mate - Account Verification",
      html: `
            <div
                style = "padding:20px 20px 40px 20px; position: relative; overflow: hidden; width: 100%;"
            >
                <div style="z-index:1; position: relative;">
                <header style="padding-bottom: 20px">
                <div class="logo" style="text-align:center;">
                    <img 
                    style="width: 150px;" 
                    src="cid:logo" alt="logo" />
                </div>
                </header>
                <main 
                style= "padding: 20px; background-color: #f5f5f5; border-radius: 10px; width: 80%; margin: 0 auto; margin-bottom: 20px; font-family: 'Poppins', sans-serif;"
                >
                <h1 
                    style="color: #FD6F3B; font-size: 30px; font-weight: 700;"
                >Welcome To Park Mate</h1>
                <p
                    style="font-size: 24px; text-align: left; font-weight: 500; font-style: italic;"
                >Hi,</p>
                <p 
                    style="font-size: 20px; text-align: left; font-weight: 500;"
                > Please use the following OTP to verify your account.</p>
                <h2
                    style="font-size: 36px; font-weight: 700; padding: 10px; width:100%; text-align:center;color: #FD6F3B; text-align: center; margin-top: 20px; margin-bottom: 20px;"
                >${otp}</h2>
                <p style = "font-size: 16px; font-style:italic; color: #343434">If you did not request this email, kindly ignore this. If this is a frequent occurence <a
                style = "color: #FD6F3B; text-decoration: none; border-bottom: 1px solid #FD6F3B;" href = "#"
                >let us know.</a></p>
                <p style = "font-size: 20px;">Regards,</p>
                <p style = "font-size: 20px;">Dev Team</p>
                </main>
                </div>
            <div>
            `,
      attachments: [
        {
          filename: "logo.jpg",
          path: "./assets/logo.jpg",
          cid: "logo",
          contentDisposition: "inline",
        },
      ],
    };

    sendEmails(
      authData.email,
      emailData.subject,
      emailData.html,
      emailData.attachments
    );

    const token = await otpTokenGen({ authData, otp });

    return next(
      CustomSuccess.createSuccess(
        { token, otp },
        "verification otp has been sent",
        200
      )
    );
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}

export async function forgotPassword(req, res, next) {
  try {
    const { error } = forgotPasswordValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    const { email } = req.body;

    const auth = await authModel.findOne({ email });
    if (!auth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    const otp = Math.floor(Math.random() * 90000) + 100000;

    await otpModel.updateOne(
      { authId: auth._doc._id },
      { otpKey: otp, isUsed: false }
    );

    const emailData = {
      subject: "Park Mate - Password Reset",
      html: `
            <div
                style = "padding:20px 20px 40px 20px; position: relative; overflow: hidden; width: 100%;"
            >
                <div style="z-index:1; position: relative;">
                <header style="padding-bottom: 20px">
                <div class="logo" style="text-align:center;">
                    <img 
                    style="width: 150px;" 
                    src="cid:logo" alt="logo" />
                </div>
                </header>
                <main 
                style= "padding: 20px; background-color: #f5f5f5; border-radius: 10px; width: 80%; margin: 0 auto; margin-bottom: 20px; font-family: 'Poppins', sans-serif;"
                >
                <h1 
                    style="color: #FD6F3B; font-size: 30px; font-weight: 700;"
                >Welcome To Park Mate</h1>
                <p
                    style="font-size: 24px; text-align: left; font-weight: 500; font-style: italic;"
                >Hi,</p>
                <p 
                    style="font-size: 20px; text-align: left; font-weight: 500;"
                > Please use the following OTP to verify your account.</p>
                <h2
                    style="font-size: 36px; font-weight: 700; padding: 10px; width:100%; text-align:center;color: #FD6F3B; text-align: center; margin-top: 20px; margin-bottom: 20px;"
                >${otp}</h2>
                <p style = "font-size: 16px; font-style:italic; color: #343434">If you did not request this email, kindly ignore this. If this is a frequent occurence <a
                style = "color: #FD6F3B; text-decoration: none; border-bottom: 1px solid #FD6F3B;" href = "#"
                >let us know.</a></p>
                <p style = "font-size: 20px;">Regards,</p>
                <p style = "font-size: 20px;">Dev Team</p>
                </main>
                </div>
            <div>
            `,
      attachments: [
        {
          filename: "logo.jpg",
          path: "./assets/logo.jpg",
          cid: "logo",
          contentDisposition: "inline",
        },
      ],
    };

    sendEmails(email, emailData.subject, emailData.html, emailData.attachments);

    const authData = {
      email,
    };

    const token = await otpTokenGen({ authData, otp });

    return next(
      CustomSuccess.createSuccess(
        { token, otp },
        "password reset otp has been sent",
        200
      )
    );
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}

export async function verifyForgotPassword(req, res, next) {
  try {
    const { error } = verifyForgotPasswordValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    const { auth } = req;
    const { otp } = req.body;

    const otpFromToken = auth.payload.data.otp;
    const authData = auth.payload.data.authData;

    if (otpFromToken.toString() !== otp) {
      return next(CustomError.createError("invalid otp", 401));
    }

    const foundAuth = await authModel.findOne({
      email: authData.email,
    });
    if (!foundAuth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    const foundOTP = await otpModel.findOne({
      authId: foundAuth._doc._id,
    });

    console.log(foundOTP.otpKey, otp);

    if (!foundOTP || foundOTP.otpKey !== otp || foundOTP.isUsed) {
      return next(CustomError.badRequest("otp already expired."));
    }

    await otpModel.updateOne({ authId: foundAuth._doc._id }, { isUsed: true });

    const token = await otpTokenGen({ authData, isVerified: true });

    return next(
      CustomSuccess.createSuccess(
        { token, authData, isVerified: true },
        "Forgot Password Verified Succesfully",
        200
      )
    );
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}

export async function resetPassword(req, res, next) {
  try {
    const { error } = resetPasswordValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    const { auth } = req;
    const { newPassword } = req.body;

    const oldAuthData = auth.payload.data.authData;
    const isVerified = auth.payload.data.isVerified;
    console.log(isVerified);

    const foundAuth = await authModel.findOne({
      email: oldAuthData.email,
    });
    if (!foundAuth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    if (!isVerified) {
      return next(CustomError.badRequest("Forgot Password Not Verified"));
    }

    const hashedPassword = hashPassword(newPassword);
    const updatedAuth = await authModel.findOneAndUpdate(
      { authId: foundAuth._doc._id },
      { password: hashedPassword }
    );

    const authData = {
      email: updatedAuth.email,
      password: updatedAuth.password,
    };

    const token = await otpTokenGen({ authData });

    return next(
      CustomSuccess.createSuccess(
        { token, authData },
        "Created New Password Succesfully",
        200
      )
    );
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}
