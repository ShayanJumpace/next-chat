import authModel from "../models/authModel.js";
import fileModel from "../models/fileModel.js";
import profileModel from "../models/profileModel.js";
import CustomError from "../Utils/ResponseHandler/CustomError.js";
import CustomSuccess from "../Utils/ResponseHandler/CustomSuccess.js";
import { createProfileValidator } from "../validators/authValidators.js";

export async function createProfile(req, res, next) {
  try {
    const { error } = createProfileValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    if (!req.file) {
      return next(CustomError.badRequest("Profile Image not found"));
    }

    const { auth } = req;
    const { fullName, contactNumber, address, preferences } = req.body;

    const { authData } = auth.payload.data;

    const foundAuth = await authModel.findOne({
      email: authData.email,
    });
    if (!foundAuth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    if (!foundAuth.isVerified) {
      return next(CustomError.badRequest("user is not verified."));
    }

    if (foundAuth.isProfileCreated) {
      return next(CustomError.badRequest("user is already created."));
    }

    const fileData = {
      authId: foundAuth._doc._id,
      fileName: req.file.filename,
      fileType: req.file.mimetype,
    };
    const newFile = await fileModel.create(fileData);

    const profileData = {
      authId: foundAuth._doc._id,
      profileImageId: newFile._doc._id,
      fullName,
      contactNumber,
      address,
      preferences,
    };
    await profileModel.create(profileData);
    await authModel.updateOne(
      { email: authData.email },
      { isProfileCreated: true }
    );

    return next(CustomSuccess.createSuccess({}, "profile created", 200));
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}
