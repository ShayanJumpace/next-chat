import authModel from "../models/authModel.js";
import CarModel from "../models/carModel.js";
import fileModel from "../models/fileModel.js";
import CustomError from "../Utils/ResponseHandler/CustomError.js";
import CustomSuccess from "../Utils/ResponseHandler/CustomSuccess.js";
import { registerCarValidator } from "../validators/authValidators.js";

export async function registerCar(req, res, next) {
  try {
    const { error } = registerCarValidator.validate(req.body, {
      abortEarly: false,
    });
    if (error) {
      return next(CustomError.badRequest(error.details[0].message));
    }

    if (!req.file) {
      return next(CustomError.badRequest("Car Image not found"));
    }

    const { auth } = req;
    const { carName, carModel, carPlateNumber, licenseNumber } = req.body;

    const { authData } = auth.payload.data;

    const foundAuth = await authModel.findOne({
      email: authData.email,
    });
    if (!foundAuth) {
      return next(CustomError.badRequest("user does not exist."));
    }

    if (!foundAuth.isVerified) {
      return next(CustomError.badRequest("user is not verified."));
    }

    if (!foundAuth.isProfileCreated) {
      return next(CustomError.badRequest("user didn't created profile."));
    }

    if (foundAuth.isCarRegistered) {
      return next(CustomError.badRequest("car is already registered."));
    }

    const fileData = {
      authId: foundAuth._doc._id,
      fileName: req.file.filename,
      fileType: req.file.mimetype,
    };
    const newFile = await fileModel.create(fileData);

    const carData = {
      authId: foundAuth._doc._id,
      carImageId: newFile._doc._id,
      carName,
      carModel,
      carPlateNumber,
      licenseNumber,
    };

    await CarModel.create(carData);
    await authModel.updateOne(
      { email: authData.email },
      { isCarRegistered: true }
    );

    return next(CustomSuccess.createSuccess({}, "car registered", 200));
  } catch (error) {
    return next(CustomError.createError(error.message, 500));
  }
}
